
//connessione
var socket = io.connect('http://localhost:8080'); // è una variabile socket diversa da quella in                 index.js
//query
var message= document.getElementById('message'); 
var handle = document.getElementById('handle');
var button = document.getElementById('send');
var output = document.getElementById('output');
var feedback = document.getElementById('feedback');
var utenti = document.getElementById('utenti');
var home = document.getElementById('h');
//scrollbar sempre in basso
function updateScroll(){
var element = document.getElementById("output");
element.scrollTop = element.scrollHeight;
} 
//emit eventi
var clients = [];
button.addEventListener('click',function() {
socket.emit('chat', {
message: message.value,
handle: handle.value
}); 
});



message.addEventListener('keypress', function() {
socket.emit('typing', handle.value);
});
//listen eventi
socket.on('chat', function(data){
if (data.message !== "" & data.handle !== "") {
if (handle.value === data.handle) {
    feedback.innerHTML= "" ;
    output.innerHTML +='<p id=inviato>' +'<span id="utente">'+'Tu' +'</span> <br> ' +    data.message +'</p> <br>';
    updateScroll();
    document.getElementById('message').value='';
    handle.disabled= true;
    clients.push("Tu");
    unique = [...new Set(clients)];
    
    utenti.innerHTML = '<p id="nome">' + unique + '</p>' ;
    
} else {
    feedback.innerHTML= "" ;
    output.innerHTML +='<p id=ricevuto>' +'<span id="utente">'+data.handle +'</span> <br> '   + data.message +'</p> <br>';
    updateScroll();
    document.getElementById('message').value='';
    clients.push(" " + data.handle);
    unique = [...new Set(clients)];
    
    
    if (unique.length > 4) {
        var ris = unique.length - 4;
        utenti.innerHTML = '<p id="nome">' + unique[0] + ", " + unique[1] + ", " + unique[2] + ", " + unique[3] + " e altri " + ris + '</p>' ;
    } else {
        utenti.innerHTML = '<p id="nome">' + unique + '</p>' ;
    }
}
} 
});




socket.on('typing', function(data) {
feedback.innerHTML = '<p>'+ data + ' sta scrivendo...' + '</p>' ;
});


